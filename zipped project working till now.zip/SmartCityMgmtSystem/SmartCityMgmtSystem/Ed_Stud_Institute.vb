﻿Public Class Ed_Stud_Institute
    Private Sub childformPanel_Paint(sender As Object, e As PaintEventArgs) Handles childformPanel.Paint

    End Sub

    Private Sub Ed_Stud_Institute_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
