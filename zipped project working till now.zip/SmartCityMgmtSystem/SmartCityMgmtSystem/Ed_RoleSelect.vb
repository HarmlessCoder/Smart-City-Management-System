﻿Public Class Ed_RoleSelect
    Private Sub Ed_RoleSelect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

End Class
